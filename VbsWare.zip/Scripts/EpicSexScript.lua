-- Gui to Lua
-- Version: 3.2

-- Instances:

local ScreenGui = Instance.new("ScreenGui")
local Frame = Instance.new("Frame")
local TextLabel = Instance.new("TextLabel")
local PlayerTextBox = Instance.new("TextBox")
local PlayButton = Instance.new("TextButton")
local Exit = Instance.new("TextButton")
local StopRape = Instance.new("TextButton")
local TextLabel_2 = Instance.new("TextLabel")

--Properties:

ScreenGui.Parent = game.Players.LocalPlayer:WaitForChild("PlayerGui")
ScreenGui.ZIndexBehavior = Enum.ZIndexBehavior.Sibling
ScreenGui.ResetOnSpawn = false

Frame.Parent = ScreenGui
Frame.BackgroundColor3 = Color3.fromRGB(30, 30, 30)
Frame.BorderColor3 = Color3.fromRGB(0, 0, 0)
Frame.BorderSizePixel = 0
Frame.Position = UDim2.new(0.302209228, 0, 0.344198167, 0)
Frame.Size = UDim2.new(0, 270, 0, 179)

TextLabel.Parent = Frame
TextLabel.BackgroundColor3 = Color3.fromRGB(20, 20, 20)
TextLabel.BorderColor3 = Color3.fromRGB(0, 0, 0)
TextLabel.BorderSizePixel = 0
TextLabel.Position = UDim2.new(0, 0, -0.00591829885, 0)
TextLabel.Size = UDim2.new(0, 270, 0, 40)
TextLabel.Font = Enum.Font.FredokaOne
TextLabel.Text = "Epic Sex Script"
TextLabel.TextColor3 = Color3.fromRGB(255, 0, 0)
TextLabel.TextSize = 28.000
TextLabel.TextWrapped = true

PlayerTextBox.Name = "PlayerTextBox"
PlayerTextBox.Parent = Frame
PlayerTextBox.BackgroundColor3 = Color3.fromRGB(20, 20, 20)
PlayerTextBox.BorderColor3 = Color3.fromRGB(0, 0, 0)
PlayerTextBox.BorderSizePixel = 0
PlayerTextBox.Position = UDim2.new(0.113605186, 0, 0.257162601, 0)
PlayerTextBox.Size = UDim2.new(0, 208, 0, 38)
PlayerTextBox.Font = Enum.Font.SourceSansBold
PlayerTextBox.PlaceholderColor3 = Color3.fromRGB(189, 0, 0)
PlayerTextBox.PlaceholderText = "Victims Name Here"
PlayerTextBox.Text = ""
PlayerTextBox.TextColor3 = Color3.fromRGB(255, 0, 0)
PlayerTextBox.TextSize = 21.000
PlayerTextBox.TextWrapped = true

PlayButton.Name = "PlayButton"
PlayButton.Parent = Frame
PlayButton.BackgroundColor3 = Color3.fromRGB(20, 20, 20)
PlayButton.BorderColor3 = Color3.fromRGB(0, 0, 0)
PlayButton.BorderSizePixel = 0
PlayButton.Position = UDim2.new(0, 32, 0, 93)
PlayButton.Size = UDim2.new(0, 207, 0, 25)
PlayButton.Font = Enum.Font.SourceSansBold
PlayButton.Text = "RAPE THEM"
PlayButton.TextColor3 = Color3.fromRGB(255, 0, 0)
PlayButton.TextSize = 14.000

Exit.Name = "Exit"
Exit.Parent = Frame
Exit.BackgroundColor3 = Color3.fromRGB(20, 20, 20)
Exit.BorderColor3 = Color3.fromRGB(255, 255, 255)
Exit.BorderSizePixel = 0
Exit.Position = UDim2.new(0, 239, 0, 7)
Exit.Size = UDim2.new(0, 25, 0, 24)
Exit.Font = Enum.Font.SourceSansBold
Exit.Text = "X"
Exit.TextColor3 = Color3.fromRGB(255, 0, 0)
Exit.TextScaled = true
Exit.TextSize = 14.000
Exit.TextWrapped = true

StopRape.Name = "StopRape"
StopRape.Parent = Frame
StopRape.BackgroundColor3 = Color3.fromRGB(20, 20, 20)
StopRape.BorderColor3 = Color3.fromRGB(0, 0, 0)
StopRape.BorderSizePixel = 0
StopRape.Position = UDim2.new(0, 60, 0, 126)
StopRape.Size = UDim2.new(0, 156, 0, 25)
StopRape.Font = Enum.Font.SourceSansBold
StopRape.Text = "Stop Raping :("
StopRape.TextColor3 = Color3.fromRGB(255, 0, 0)
StopRape.TextSize = 14.000

TextLabel_2.Parent = Frame
TextLabel_2.BackgroundColor3 = Color3.fromRGB(30, 30, 20)
TextLabel_2.BorderColor3 = Color3.fromRGB(0, 0, 0)
TextLabel_2.BorderSizePixel = 0
TextLabel_2.Position = UDim2.new(0, 155, 0, 163)
TextLabel_2.Size = UDim2.new(0, 115, 0, 16)
TextLabel_2.Font = Enum.Font.SourceSansBold
TextLabel_2.Text = "By - Grandma96523"
TextLabel_2.TextColor3 = Color3.fromRGB(255, 0, 0)
TextLabel_2.TextSize = 14.000

-- Scripts:

local function GJIG_fake_script() -- Frame.LocalScript 
\tlocal script = Instance.new('LocalScript', Frame)

\tlocal playerNameTextBox = script.Parent:WaitForChild("PlayerTextBox")
\tlocal playButton = script.Parent:WaitForChild("PlayButton")
\tlocal stopRapeButton = script.Parent:WaitForChild("StopRape")
\tlocal exitButton = script.Parent:WaitForChild("Exit")
\tlocal gui = script.Parent
\tlocal animationPlaying = nil
\tlocal runServiceConnection = nil
\t
\tplayButton.MouseButton1Click:Connect(function()
\t\tlocal Victim = playerNameTextBox.Text
\t\tlocal playerFound = nil
\t
\t\t-- Check for a player by their username or nickname
\t\tfor _, player in pairs(game:GetService("Players"):GetPlayers()) do
\t\t\tif player.Name == Victim or player.DisplayName == Victim then
\t\t\t\tplayerFound = player
\t\t\t\tbreak
\t\t\tend
\t\tend
\t
\t\tif playerFound then
\t\t\tlocal A = Instance.new("Animation")
\t\t\tA.AnimationId = 'rbxassetid://148840371'
\t\t\tlocal P = game:GetService("Players").LocalPlayer
\t\t\tlocal C = P.Character or P.CharacterAdded:Wait()
\t\t\tlocal H = C:WaitForChild("Humanoid"):LoadAnimation(A)
\t\t\tH:Play()
\t\t\tH:AdjustSpeed(2.5)
\t
\t\t\tanimationPlaying = H
\t
\t\t\trunServiceConnection = game:GetService("RunService").Stepped:Connect(function()
\t\t\t\tif playerFound.Character then
\t\t\t\t\tlocal victimRootPart = playerFound.Character:FindFirstChild("HumanoidRootPart")
\t\t\t\t\tlocal localRootPart = C:WaitForChild("HumanoidRootPart")
\t
\t\t\t\t\tif victimRootPart then
\t\t\t\t\t\tlocal offset = victimRootPart.CFrame.LookVector * -1
\t\t\t\t\t\tlocalRootPart.CFrame = CFrame.new(victimRootPart.Position + offset, victimRootPart.Position)
\t\t\t\t\tend
\t\t\t\tend
\t\t\tend)
\t\telse
\t\t\tprint("No player found with the name or nickname " .. Victim)
\t\tend
\tend)
\t
\tstopRapeButton.MouseButton1Click:Connect(function()
\t\tif animationPlaying then
\t\t\tanimationPlaying:Stop()
\t\t\tprint("Animation stopped.")
\t\tend
\t\tif runServiceConnection then
\t\t\trunServiceConnection:Disconnect()
\t\t\tprint("Teleportation stopped.")
\t\tend
\tend)
\t
\texitButton.MouseButton1Click:Connect(function()
\t\tgui.Visible = false
\t\tprint("GUI closed. Press right Shift to reopen.")
\tend)
\t
\tgame:GetService("UserInputService").InputBegan:Connect(function(input, gameProcessed)
\t\tif input.KeyCode == Enum.KeyCode.RightShift and not gameProcessed then
\t\t\tgui.Visible = not gui.Visible
\t\tend
\tend)
\t
\tlocal corner = Instance.new("UICorner")
\tcorner.CornerRadius = UDim.new(0, 12)
\tcorner.Parent = gui
\t
\tlocal dragging
\tlocal dragStart
\tlocal startPos
\t
\tgui.InputBegan:Connect(function(input)
\t\tif input.UserInputType == Enum.UserInputType.MouseButton1 then
\t\t\tdragging = true
\t\t\tdragStart = input.Position
\t\t\tstartPos = gui.Position
\t
\t\t\tinput.Changed:Connect(function()
\t\t\t\tif input.UserInputState == Enum.UserInputState.End then
\t\t\t\t\tdragging = false
\t\t\t\tend
\t\t\tend)
\t\tend
\tend)
\t
\tgui.InputChanged:Connect(function(input)
\t\tif dragging and input.UserInputType == Enum.UserInputType.MouseMovement then
\t\t\tlocal delta = input.Position - dragStart
\t\t\tgui.Position = UDim2.new(startPos.X.Scale, startPos.X.Offset + delta.X, startPos.Y.Scale, startPos.Y.Offset + delta.Y)
\t\tend
\tend)
end
coroutine.wrap(GJIG_fake_script)()